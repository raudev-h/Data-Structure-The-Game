package dominion.core;

public enum Color {
    Azul,
    Rojo
}
