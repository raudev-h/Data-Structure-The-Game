package dominion.core;

public enum AttackResult {
    VICTORY,
    DEFEAT,
    INVALID;


}
