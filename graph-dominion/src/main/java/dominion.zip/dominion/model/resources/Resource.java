package main.java.dominion.model.resources;

public enum Resource {
    Oro,
    Madera
}
