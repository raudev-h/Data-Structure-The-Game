package dominion.model.resources;

public enum ResourceType {
    WOOD,
    GOLD,
}
