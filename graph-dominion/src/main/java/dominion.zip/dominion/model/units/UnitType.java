package dominion.model.units;

public enum UnitType {
    KNIGHT,
    ARCHER
}
