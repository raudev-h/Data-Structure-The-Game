package dominion.model.units;

public class Miner extends ResourceCollector{
}
