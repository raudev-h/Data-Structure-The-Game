package dominion.model.units;

public class WoodCutter extends ResourceCollector{
}
