package dominion.model.buildings;

public enum BuildingType {
    HOUSE,
    MILITARY_BASE,
    CASTLE
}
